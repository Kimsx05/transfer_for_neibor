Patient/source/cell/bag/section IDs are stable pseudonyms in tables. No identity key, full metadata, counts or models. Dataset labels retained.
