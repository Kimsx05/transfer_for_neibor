# 图件索引

白底Arial；PNG300dpi；PDF文字/坐标/图例矢量，密集空间点栅格化。带图例图另有`_panel_only.pdf`和`_legend_only.pdf`。每一图的统计单位均为区域。

| figure | description |
| --- | --- |
| definition_counts | All five sections; T32 regions, not cells. |
| label_overlap | Mutually exclusive overlap categories; remaining eligible T regions in table. |
| continuous_effect_r50 | Continuous all eligible U_r, independent Epi mean; no new formal P. Prespecified covariates and 400/800μm blocks. |
| continuous_effect_r200 | Continuous all eligible U_r, independent Epi mean; no new formal P. Prespecified covariates and 400/800μm blocks. |
| calibration_full_rule | Pooled display only; selection used every nonempty training condition. Holdout previously viewed. No HD labels replaced. |
| Cervilla_program | All T-eligible scores including zero. Gray supplied T32 below measurement eligibility; white no represented input. MPBC relative coordinates, original tissue unknown. |
| Cervilla_labels | Original strict unchanged; simple FOXP3 label has no UCell/core gate; background supplied ineligible T32. |
| Cervilla_Epi_MP10 | Unqualified Epi regions gray-blue, not MP10-low; zero is a computed value; no score interpolation. |
| Cervilla_Epi_H05 | Within-section q95 strict greater-than; includes no tied-value forcing. |
| Cervilla_evaluability | Full T-eligible denominator. Not evaluable is missing neighborhood measurement, not non-high exposure. |
| D1_Johnson_program | All T-eligible scores including zero. Gray supplied T32 below measurement eligibility; white no represented input. MPBC relative coordinates, original tissue unknown. |
| D1_Johnson_labels | Original strict unchanged; simple FOXP3 label has no UCell/core gate; background supplied ineligible T32. |
| D1_Johnson_Epi_MP10 | Unqualified Epi regions gray-blue, not MP10-low; zero is a computed value; no score interpolation. |
| D1_Johnson_Epi_H05 | Within-section q95 strict greater-than; includes no tied-value forcing. |
| D1_Johnson_evaluability | Full T-eligible denominator. Not evaluable is missing neighborhood measurement, not non-high exposure. |
| UC_SCC_program | All T-eligible scores including zero. Gray supplied T32 below measurement eligibility; white no represented input. MPBC relative coordinates, original tissue unknown. |
| UC_SCC_labels | Original strict unchanged; simple FOXP3 label has no UCell/core gate; background supplied ineligible T32. |
| UC_SCC_Epi_MP10 | Unqualified Epi regions gray-blue, not MP10-low; zero is a computed value; no score interpolation. |
| UC_SCC_Epi_H05 | Within-section q95 strict greater-than; includes no tied-value forcing. |
| UC_SCC_evaluability | Full T-eligible denominator. Not evaluable is missing neighborhood measurement, not non-high exposure. |
| MPBC1_program | All T-eligible scores including zero. Gray supplied T32 below measurement eligibility; white no represented input. MPBC relative coordinates, original tissue unknown. |
| MPBC1_labels | Original strict unchanged; simple FOXP3 label has no UCell/core gate; background supplied ineligible T32. |
| MPBC1_Epi_MP10 | Unqualified Epi regions gray-blue, not MP10-low; zero is a computed value; no score interpolation. |
| MPBC1_Epi_H05 | Within-section q95 strict greater-than; includes no tied-value forcing. |
| MPBC1_evaluability | Full T-eligible denominator. Not evaluable is missing neighborhood measurement, not non-high exposure. |
| MPBC2_program | All T-eligible scores including zero. Gray supplied T32 below measurement eligibility; white no represented input. MPBC relative coordinates, original tissue unknown. |
| MPBC2_labels | Original strict unchanged; simple FOXP3 label has no UCell/core gate; background supplied ineligible T32. |
| MPBC2_Epi_MP10 | Unqualified Epi regions gray-blue, not MP10-low; zero is a computed value; no score interpolation. |
| MPBC2_Epi_H05 | Within-section q95 strict greater-than; includes no tied-value forcing. |
| MPBC2_evaluability | Full T-eligible denominator. Not evaluable is missing neighborhood measurement, not non-high exposure. |
| Cervilla_Kcross_descriptive | Globally source-disjoint subset;8μm supplied in-tissue pixel window; homogeneous border estimate. Nonuniformity unresolved, not formal attraction test. |
| D1_Johnson_Kcross_descriptive | Globally source-disjoint subset;8μm supplied in-tissue pixel window; homogeneous border estimate. Nonuniformity unresolved, not formal attraction test. |
| UC_SCC_Kcross_descriptive | Globally source-disjoint subset;8μm supplied in-tissue pixel window; homogeneous border estimate. Nonuniformity unresolved, not formal attraction test. |
| Cervilla_continuous_r200 | All U200; no strict/FOXP3 gate. One T32 per point; overlapping neighborhoods not independent patients. |
| Cervilla_null_edges_r50 | 9999 samples; counts retained even where no valid formal inference, e.g. zero null SD. |
| Cervilla_null_edges_r200 | 9999 samples; counts retained even where no valid formal inference, e.g. zero null SD. |
| D1_Johnson_continuous_r200 | All U200; no strict/FOXP3 gate. One T32 per point; overlapping neighborhoods not independent patients. |
| D1_Johnson_null_edges_r50 | 9999 samples; counts retained even where no valid formal inference, e.g. zero null SD. |
| D1_Johnson_null_edges_r200 | 9999 samples; counts retained even where no valid formal inference, e.g. zero null SD. |
| UC_SCC_continuous_r200 | All U200; no strict/FOXP3 gate. One T32 per point; overlapping neighborhoods not independent patients. |
| UC_SCC_null_edges_r50 | 9999 samples; counts retained even where no valid formal inference, e.g. zero null SD. |
| UC_SCC_null_edges_r200 | 9999 samples; counts retained even where no valid formal inference, e.g. zero null SD. |
| MPBC1_continuous_r200 | All U200; no strict/FOXP3 gate. One T32 per point; overlapping neighborhoods not independent patients. |
| MPBC1_null_edges_r50 | 9999 samples; counts retained even where no valid formal inference, e.g. zero null SD. |
| MPBC1_null_edges_r200 | 9999 samples; counts retained even where no valid formal inference, e.g. zero null SD. |
| MPBC2_continuous_r200 | All U200; no strict/FOXP3 gate. One T32 per point; overlapping neighborhoods not independent patients. |
| MPBC2_null_edges_r50 | 9999 samples; counts retained even where no valid formal inference, e.g. zero null SD. |
| MPBC2_null_edges_r200 | 9999 samples; counts retained even where no valid formal inference, e.g. zero null SD. |
| MS_label_to_high_Epi_r50 | Unordered A-A; cross pair once, isolates included. No pseudocount. |
| MS_high_Epi_to_label_r50 | Unordered A-A; cross pair once, isolates included. No pseudocount. |
| MS_label_to_high_Epi_r200 | Unordered A-A; cross pair once, isolates included. No pseudocount. |
| MS_high_Epi_to_label_r200 | Unordered A-A; cross pair once, isolates included. No pseudocount. |
| FE_block_sensitivity | Matched center-based block intervals; invalid-draw fractions in table. |
| hotspot_influence | Dots original; line min/max from prespecified64µm linked-positive components. Unchanged remaining Epi neighborhoods; no model selection. |
| Cervilla_ROI_candidate_1 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| Cervilla_ROI_candidate_2 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| Cervilla_ROI_control_1 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| Cervilla_ROI_control_2 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| D1_Johnson_ROI_candidate_1 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| D1_Johnson_ROI_candidate_2 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| D1_Johnson_ROI_candidate_3 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| D1_Johnson_ROI_candidate_4 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| D1_Johnson_ROI_control_1 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| D1_Johnson_ROI_control_2 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| UC_SCC_ROI_candidate_1 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| UC_SCC_ROI_candidate_2 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| UC_SCC_ROI_candidate_3 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| UC_SCC_ROI_candidate_4 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| UC_SCC_ROI_control_1 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| UC_SCC_ROI_control_2 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| MPBC1_ROI_candidate_1 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| MPBC1_ROI_candidate_2 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| MPBC1_ROI_control_1 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| MPBC1_ROI_control_2 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| MPBC2_ROI_candidate_1 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| MPBC2_ROI_candidate_2 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| MPBC2_ROI_control_1 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| MPBC2_ROI_control_2 | Same fixed ROI center;512μm display,50/200µm cumulative circles. Shows all nearby scoreable Epi incl pairs excluded from inference; pair counts in ROI table distinguish sources. No H&E fabricated; original raw evidence atlas referenced. |
| FE_H05_r50 | 400μm spatial-block intervals; NA retained. Right: positive/all U_r centers. Strict is historical sensitivity. |
| edge_Z_H05_r50 | Edges weight centers by their number of high Epi neighbors; distinct from center-based FE. |
| NMS_label_to_high_Epi_r50 | Direction fixed in filename; right n_A/n_B includes isolated points. NMS=1 is not a tissue-adjusted null. |
| NMS_high_Epi_to_label_r50 | Direction fixed in filename; right n_A/n_B includes isolated points. NMS=1 is not a tissue-adjusted null. |
| FE_H05_r200 | 400μm spatial-block intervals; NA retained. Right: positive/all U_r centers. Strict is historical sensitivity. |
| edge_Z_H05_r200 | Edges weight centers by their number of high Epi neighbors; distinct from center-based FE. |
| NMS_label_to_high_Epi_r200 | Direction fixed in filename; right n_A/n_B includes isolated points. NMS=1 is not a tissue-adjusted null. |
| NMS_high_Epi_to_label_r200 | Direction fixed in filename; right n_A/n_B includes isolated points. NMS=1 is not a tissue-adjusted null. |
| Cervilla_distance_FOXP3_supported | Fixed U200 for every radius; same source mask and9999 restricted permutations; not Kcross or simultaneous envelope. Null support=True |
| Cervilla_distance_strict | Fixed U200 for every radius; same source mask and9999 restricted permutations; not Kcross or simultaneous envelope. Null support=False |
| D1_Johnson_distance_FOXP3_supported | Fixed U200 for every radius; same source mask and9999 restricted permutations; not Kcross or simultaneous envelope. Null support=True |
| D1_Johnson_distance_strict | Fixed U200 for every radius; same source mask and9999 restricted permutations; not Kcross or simultaneous envelope. Null support=True |
| UC_SCC_distance_FOXP3_supported | Fixed U200 for every radius; same source mask and9999 restricted permutations; not Kcross or simultaneous envelope. Null support=True |
| UC_SCC_distance_strict | Fixed U200 for every radius; same source mask and9999 restricted permutations; not Kcross or simultaneous envelope. Null support=False |
| MPBC1_distance_FOXP3_supported | Fixed U200 for every radius; same source mask and9999 restricted permutations; not Kcross or simultaneous envelope. Null support=True |
| MPBC1_distance_strict | Fixed U200 for every radius; same source mask and9999 restricted permutations; not Kcross or simultaneous envelope. Null support=False |
| MPBC2_distance_FOXP3_supported | Fixed U200 for every radius; same source mask and9999 restricted permutations; not Kcross or simultaneous envelope. Null support=True |
| MPBC2_distance_strict | Fixed U200 for every radius; same source mask and9999 restricted permutations; not Kcross or simultaneous envelope. Null support=False |
| distribution_Treg_main | All T-eligible; FOXP3-supported versus remaining evaluable T. Frozen values; no new scores or tests. |
| distribution_log10_UMI | All T-eligible; FOXP3-supported versus remaining evaluable T. Frozen values; no new scores or tests. |
| distribution_log1p_FOXP3 | All T-eligible; FOXP3-supported versus remaining evaluable T. Frozen values; no new scores or tests. |
| distribution_log1p_IL2RA | All T-eligible; FOXP3-supported versus remaining evaluable T. Frozen values; no new scores or tests. |
| distribution_log1p_CTLA4 | All T-eligible; FOXP3-supported versus remaining evaluable T. Frozen values; no new scores or tests. |

原固定24个ROI的原始多基因、H&E或表达覆盖图册继续引用v2，路径见`tables/ROI_interpretation.tsv`。本轮24个新图为新标签与H05配对几何覆盖叠图，未替换旧原始表达证据。
