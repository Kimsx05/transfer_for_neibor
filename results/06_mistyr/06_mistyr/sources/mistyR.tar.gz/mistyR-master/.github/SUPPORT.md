# Getting help with `mistyR`

Thanks for using `mistyR`! Before filing an issue, there are a few places to explore and pieces to put together to make the process as smooth as possible.

## Make a reprex

Start by making a minimal **repr**oducible **ex**ample using the [reprex](https://reprex.tidyverse.org/) package. If you haven't heard of or used reprex before, you're in for a treat! Seriously, reprex will make all of your R-question-asking endeavors easier (which is a pretty insane ROI for the five to ten minutes it'll take you to learn what it's all about). For additional reprex pointers, check out the [Get help!](https://www.tidyverse.org/help/) section of the tidyverse site.

## Where to ask?

Armed with your reprex, the next step is to figure out [where to ask](https://www.tidyverse.org/help/#where-to-ask). See also the [Bioconductor help](http://bioconductor.org/help/) website.

-   If it's a question: start with [community.rstudio.com](https://community.rstudio.com/), and/or StackOverflow. If this a Bioconductor-related question, please ask it at the [Bioconductor Support Website](https://support.bioconductor.org/) using the [appropriate package tag](https://support.bioconductor.org/t/mistyR) (the website will send an automatic email to the package authors). There are more people there to answer questions.

-   If it's a bug: you're in the right place, [file an issue](https://github.com/saezlab/mistyR/issues/new).

-   If you're not sure: let the community help you figure it out! If your problem *is* a bug or a feature request, you can easily return here and report it.

Before opening a new issue, be sure to [search issues and pull requests](https://github.com/saezlab/mistyR/issues) to make sure the bug hasn't been reported and/or already fixed in the development version. By default, the search will be pre-populated with `is:issue is:open`. You can [edit the qualifiers](https://help.github.com/articles/searching-issues-and-pull-requests/) (e.g. `is:pr`, `is:closed`) as needed. For example, you'd simply remove `is:open` to search *all* issues in the repo, open or closed.
